<?php
global $sqltag;
// phpwind8���ݿ���������
// ------------------------------------------------------------------------
$sqltag['phpwind8']['dbhost'] = 'localhost';
$sqltag['phpwind8']['dbname'] = 'phpwind8';
$sqltag['phpwind8']['dbuser'] = 'root';
$sqltag['phpwind8']['dbpwd'] = '123456';
$sqltag['phpwind8']['dbprefix'] = 'pw_';
$sqltag['phpwind8']['dblanguage'] = 'gbk';

// phpb2b���ݿ���������
// ------------------------------------------------------------------------
$sqltag['phpb2b']['dbhost'] = 'localhost';
$sqltag['phpb2b']['dbname'] = 'phpb2b';
$sqltag['phpb2b']['dbuser'] = 'root';
$sqltag['phpb2b']['dbpwd'] = '123456';
$sqltag['phpb2b']['dbprefix'] = 'pb_';
$sqltag['phpb2b']['dblanguage'] = 'utf8';
?>